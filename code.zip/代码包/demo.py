#! /usr/local/bin/python3

import time

from turing_models.utilities.turing_date import TuringDate
from turing_models.utilities.global_types import TuringOptionTypes
from turing_models.utilities.day_count import TuringDayCountTypes
from turing_models.products.equity.equity_vanilla_option import TuringEquityVanillaOption
from turing_models.products.equity.equity_american_option import TuringEquityAmericanOption
from turing_models.models.model_black_scholes import TuringModelBlackScholes, TuringModelBlackScholesTypes
from turing_models.market.curves.discount_curve_flat import TuringDiscountCurveFlat

# --------------------------------------------------------------------------
# Section 1: Pricing
# --------------------------------------------------------------------------
# Params
value_date = TuringDate(y=2021, m=4, d=25)
expiry_date = TuringDate(y=2021, m=10, d=25)
strike_price = 500
volatility = 0.02
num_options = 100

stock_price = 510
interest_rate = 0.03
dividend_yield = 0

# Model Definition
model_tree = TuringModelBlackScholes(
    volatility,
    implementationType=TuringModelBlackScholesTypes.CRR_TREE,
    numStepsPerYear=10000)
discount_curve = TuringDiscountCurveFlat(
    value_date,
    interest_rate,
    dayCountType=TuringDayCountTypes.ACT_365F)
dividend_curve = TuringDiscountCurveFlat(
    value_date,
    dividend_yield,
    dayCountType=TuringDayCountTypes.ACT_365F)

time_start = time.time()

# 可以修改循环次数
for _ in range(1):
    # Option Definition
    vanilla_option = TuringEquityVanillaOption(
        expiry_date, strike_price, TuringOptionTypes.EUROPEAN_CALL)

    american_option = TuringEquityAmericanOption(
        expiry_date, strike_price, TuringOptionTypes.AMERICAN_PUT)

    # Pricing
    vanilla_option_price_crr = vanilla_option.value_crr(
        value_date,
        stock_price,
        discount_curve,
        dividend_curve,
        model_tree) * num_options
    vanilla_option_price_mc = vanilla_option.valueMC_NUMPY_NUMBA(
        value_date,
        stock_price,
        discount_curve,
        dividend_curve,
        model_tree) * num_options
    vanilla_option_delta = vanilla_option.delta(
        value_date,
        stock_price,
        discount_curve,
        dividend_curve,
        model_tree) * num_options
    vanilla_option_gamma = vanilla_option.gamma(
        value_date,
        stock_price,
        discount_curve,
        dividend_curve,
        model_tree) * num_options
    vanilla_option_vega = vanilla_option.vega(
        value_date,
        stock_price,
        discount_curve,
        dividend_curve,
        model_tree) * num_options

    american_option_price = american_option.value(
        value_date,
        stock_price,
        discount_curve,
        dividend_curve,
        model_tree) * num_options

    print("[Vanilla] Option Price(use crr): {}, Option Price(use MC): {}, Delta: {}, Gamma: {}, Vega: {} [American] Option Price: {}".format(
        vanilla_option_price_crr, vanilla_option_price_mc,
        vanilla_option_delta, vanilla_option_gamma,
        vanilla_option_vega, american_option_price))

time_end = time.time()
print('Time cost = %fs' % (time_end - time_start))
